import java.util.*;
class CopyOnWriteArraySetTest
{
public static void main(String args[])
{
Set<String> copyOnWriteArraySet=new CopyOnWriteArraySet<String>();
copyOnWriteArraySet.add("a");
copyOnWriteArraySet.add("b");
Iterator<String>iterator=copyOnWriteArraySet.iterator();
while(iterator.hasNext())
{
copyOnWriteArraySet.add("c");
System.out.println(iterator.next());
}
}
}