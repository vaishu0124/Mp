package com.fis.demo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.fis.demo.entity.Product;

@Repository
public class ProductDaoImpl implements ProductDao {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		return "Product Added Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		entityManager.merge(product);
		return "Product update Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		entityManager.remove(getProduct(productId));
		return "Product Remoed Successfully";
	}

	@Override
	public Product getProduct(int productId) {

		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {
		Query query= entityManager.createQuery("select p from Product p");
		return query.getResultList();
	}

}
