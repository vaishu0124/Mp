class A{

A(int a){
this();
System.out.println("4");
}
{
System.out.println("5");
}
public static void main(String args[]){
A o=new A(20);
System.out.println("6");
}
}