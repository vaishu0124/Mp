class Printvalue
{
<t> void display(t obj[])
{
for (t i:obj){
System.out.println(i+"");
}
}
}
public class Myclass
{
	public static void main(String args[])
{
PrintValue obj1=new PrintValue();
Integer i[]={1,2};
obj1.display(i);
Double d[]={1.1,2.2};
obj1.display(d);
}
}
