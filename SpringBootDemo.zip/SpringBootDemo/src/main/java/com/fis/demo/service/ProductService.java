package com.fis.demo.service;

import java.util.List;

import com.fis.demo.entity.Product;

public interface ProductService {

	public String addProduct(Product product);

	public String updateProduct(Product product);

	public String deleteProduct(int productId);

	public Product getProduct(int productId);

	public List<Product> getAllProducts();

}
