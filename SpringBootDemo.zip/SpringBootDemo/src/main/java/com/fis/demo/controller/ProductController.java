package com.fis.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.demo.entity.Product;
import com.fis.demo.service.ProductService;

@RequestMapping("/welcome")
@RestController
public class ProductController {
	@Autowired
	ProductService service;

	@GetMapping("/message") // http://localhost:1112/welcome/message
	public String printMessage() {
		return "welcome to springbootrest";
	}

	@GetMapping("/getProduct/{id}") // http://localhost:1112/welcome/getProduct/111
	public Product getProduct(@PathVariable("id") int productId) {
		return service.getProduct(productId);// jackson
	}

	@PostMapping("/addProduct") // http://localhost:1112/welcome/addProduct
	public String addProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/updateProduct") // http://localhost:1112/welcome/updateProduct
	public String updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/deleteProduct/{id}") // http://localhost:1112/welcome/getProduct/111
	public String deleteProduct(@PathVariable("id") int productId) {
		return service.deleteProduct(productId);// jackson
	}

	@GetMapping("/getAllProducts") // http://localhost:1112/welcome/getProduct/111
	public List<Product> getProducts() {
		return service.getAllProducts();// jackson
	}
}